# Progetto Gym-Cards

## Istruzioni per l'installazione

1. Estrai questo archivio in una directory
2. Apri un terminale nella directory estratta
3. Esegui `npm install` per installare le dipendenze
4. Esegui `ng serve` per avviare l'applicazione
5. Apri un browser e vai a http://localhost:4200

## Requisiti

- Node.js (v14 o superiore)
- Angular CLI (v14 o superiore)

## Dipendenze principali

- Angular
- html2pdf.js
- jspdf
