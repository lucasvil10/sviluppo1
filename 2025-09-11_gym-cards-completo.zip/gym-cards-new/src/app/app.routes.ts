import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AllenamentoComponent } from './allenamento/allenamento.component';
import { SchedaEsercizi } from './scheda-esercizi/scheda-esercizi';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'allenamento', component: AllenamentoComponent },
  { path: 'esercizi', component: SchedaEsercizi },
  { path: '**', redirectTo: 'home' }
];
