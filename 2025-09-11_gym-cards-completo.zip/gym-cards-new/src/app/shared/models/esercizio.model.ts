export interface Esercizio {
  id?: string;
  nome: string;
  descrizione: string;
  imagePath: string;
  imageUrl?: string;
  categoria?: string;
  data: Date;
}