import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedaEsercizi } from './scheda-esercizi';

describe('SchedaEsercizi', () => {
  let component: SchedaEsercizi;
  let fixture: ComponentFixture<SchedaEsercizi>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SchedaEsercizi]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SchedaEsercizi);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
