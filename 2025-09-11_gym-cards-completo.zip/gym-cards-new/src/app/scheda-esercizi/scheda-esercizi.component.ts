import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Esercizio {
  id?: string;
  nome: string;
  descrizione: string;
  imagePath: string;
  imageUrl?: string;
  categoria?: string;
  data: Date;
}

@Component({
  selector: 'app-scheda-esercizi',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './scheda-esercizi.component.html',
  styleUrls: ['./scheda-esercizi.component.css']
})
export class SchedaEserciziComponent implements OnInit {
  esercizi: Esercizio[] = [];
  nuovoEsercizio: Esercizio = {
    nome: '',
    descrizione: '',
    imagePath: '',
    categoria: '',
    data: new Date()
  };
  selectedFile: File | null = null;
  imagePreview: string | undefined;
  editMode = false;
  currentEditId: string | undefined;
  categorie = ['Gambe', 'Petto', 'Braccia', 'Schiena', 'Addominali', 'Cardio', 'Altro'];

  constructor() {}

  ngOnInit() {
    this.loadEsercizi();
  }

  loadEsercizi() {
    // Carica gli esercizi dal localStorage
    const savedEsercizi = localStorage.getItem('esercizi');
    if (savedEsercizi) {
      this.esercizi = JSON.parse(savedEsercizi);
    }
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result as string;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  salvaEsercizio() {
    if (!this.nuovoEsercizio.nome || !this.imagePreview) {
      alert('Inserisci un nome e seleziona un\'immagine');
      return;
    }

    if (this.editMode && this.currentEditId) {
      // Modifica esercizio esistente
      const index = this.esercizi.findIndex(e => e.id === this.currentEditId);
      if (index !== -1) {
        this.esercizi[index] = {
          ...this.nuovoEsercizio,
          id: this.currentEditId,
          imageUrl: this.imagePreview,
          imagePath: this.selectedFile ? this.selectedFile.name : this.esercizi[index].imagePath
        };
        this.salvaInStorage();
      }
    } else {
      // Nuovo esercizio
      const newId = Date.now().toString();
      const newEsercizio: Esercizio = {
        ...this.nuovoEsercizio,
        id: newId,
        imageUrl: this.imagePreview,
        imagePath: this.selectedFile ? this.selectedFile.name : '',
        data: new Date()
      };
      
      this.esercizi.push(newEsercizio);
      this.salvaInStorage();
    }
    
    this.resetForm();
  }

  salvaInStorage() {
    localStorage.setItem('esercizi', JSON.stringify(this.esercizi));
  }

  editEsercizio(esercizio: Esercizio) {
    this.editMode = true;
    this.currentEditId = esercizio.id;
    this.nuovoEsercizio = { ...esercizio };
    this.imagePreview = esercizio.imageUrl;
  }

  deleteEsercizio(id: string | undefined) {
    if (!id) return;
    
    if (confirm('Sei sicuro di voler eliminare questo esercizio?')) {
      this.esercizi = this.esercizi.filter(e => e.id !== id);
      this.salvaInStorage();
    }
  }

  resetForm() {
    this.editMode = false;
    this.currentEditId = undefined;
    this.nuovoEsercizio = {
      nome: '',
      descrizione: '',
      imagePath: '',
      categoria: '',
      data: new Date()
    };
    this.selectedFile = null;
    this.imagePreview = undefined;
  }
}