import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Esercizio {
  id: string;
  nome: string;
  descrizione: string;
  imageUrl: string;
  categoria: string;
  data: Date;
}

@Component({
  selector: 'app-scheda-esercizi',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './scheda-esercizi.html',
  styleUrls: ['./scheda-esercizi.css']
})
export class SchedaEsercizi implements OnInit {
  esercizi: Esercizio[] = [];
  nuovoEsercizio: Esercizio = {
    id: '',
    nome: '',
    descrizione: '',
    imageUrl: '',
    categoria: '',
    data: new Date()
  };
  
  // Proprietà carousel
  currentSlideIndex = 0;
  
  selectedFile: File | null = null;
  imagePreview: string | undefined;
  editMode = false;
  currentEditId: string | undefined;
  categorie = ['Gambe', 'Petto', 'Braccia', 'Schiena', 'Addominali', 'Cardio', 'Altro'];

  constructor() {}

  ngOnInit() {
    this.loadEsercizi();
  }

  loadEsercizi() {
    const savedEsercizi = localStorage.getItem('esercizi');
    this.esercizi = savedEsercizi ? JSON.parse(savedEsercizi) : [];
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result as string;
      };
      reader.readAsDataURL(this.selectedFile);
    }
  }

  salvaEsercizio() {
    if (!this.nuovoEsercizio.nome || !this.imagePreview) {
      alert('Inserisci un nome e seleziona un\'immagine');
      return;
    }

    const esercizioToSave: Esercizio = {
      ...this.nuovoEsercizio,
      id: this.editMode && this.currentEditId ? this.currentEditId : Date.now().toString(),
      imageUrl: this.imagePreview,
      data: new Date()
    };
    
    if (this.editMode && this.currentEditId) {
      // Aggiorna esercizio esistente
      const index = this.esercizi.findIndex(e => e.id === this.currentEditId);
      if (index !== -1) {
        this.esercizi[index] = esercizioToSave;
      }
    } else {
      // Nuovo esercizio
      this.esercizi.push(esercizioToSave);
    }
    
    localStorage.setItem('esercizi', JSON.stringify(this.esercizi));
    this.resetForm();
  }

  editEsercizio(esercizio: Esercizio) {
    this.editMode = true;
    this.currentEditId = esercizio.id;
    this.nuovoEsercizio = { ...esercizio };
    this.imagePreview = esercizio.imageUrl;
  }

  deleteEsercizio(id: string) {
    if (confirm('Sei sicuro di voler eliminare questo esercizio?')) {
      this.esercizi = this.esercizi.filter(e => e.id !== id);
      localStorage.setItem('esercizi', JSON.stringify(this.esercizi));
    }
  }

  resetForm() {
    this.editMode = false;
    this.currentEditId = undefined;
    this.nuovoEsercizio = {
      id: '',
      nome: '',
      descrizione: '',
      imageUrl: '',
      categoria: '',
      data: new Date()
    };
    this.selectedFile = null;
    this.imagePreview = undefined;
  }
  
  // Metodi per il carousel
  nextSlide() {
    if (this.esercizi.length === 0) return;
    this.currentSlideIndex = (this.currentSlideIndex + 1) % this.esercizi.length;
  }
  
  prevSlide() {
    if (this.esercizi.length === 0) return;
    this.currentSlideIndex = (this.currentSlideIndex - 1 + this.esercizi.length) % this.esercizi.length;
  }
  
  goToSlide(index: number) {
    this.currentSlideIndex = index;
  }
}
